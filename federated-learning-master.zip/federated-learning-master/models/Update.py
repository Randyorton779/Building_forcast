#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6

import torch
from torch import nn, autograd
from torch.utils.data import DataLoader, Dataset
import numpy as np
import random
from sklearn import metrics
import torch
import torch.nn as nn
from torch.utils.data import DataLoader


class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset  # dataset 是 TensorDataset，包含特征和目标值
        self.idxs = list(idxs)  # idxs 是传入的索引列表，表示客户端的数据子集

    def __len__(self):
        return len(self.idxs)  # 返回客户端拥有的数据数量

    def __getitem__(self, item):
        # 从 self.dataset 中提取特征和目标
        features, target = self.dataset[self.idxs[item]]  # 根据索引获取数据
        return features, target  # 返回特征和目标值

class LocalUpdate(object):
    def __init__(self, args, dataset):
        self.args = args
        self.loss_func = nn.MSELoss()  # 使用均方误差作为损失函数，适合回归任务
        self.ldr_train = DataLoader(dataset, batch_size=self.args.local_bs, shuffle=True)  # 加载局部数据集

    def train(self, net):
        net.train()
        # 定义优化器
        optimizer = torch.optim.Adam(net.parameters(), lr=self.args.lr)

        epoch_loss = []
        for iter in range(self.args.local_ep):  # 多个本地训练 epoch
            batch_loss = []
            for batch_idx, (features, target) in enumerate(self.ldr_train):
                # 将特征和目标移动到设备（GPU 或 CPU）
                features, target = features.to(self.args.device), target.to(self.args.device)

                # 重置梯度
                optimizer.zero_grad()

                # 前向传播，LSTM 需要额外的维度 (batch_size, seq_length, input_size)
                  # 为 LSTM 模型扩展一个输入通道的维度
                # output = net(features.unsqueeze(2))
                output = net(features)
                # 计算损失
                loss = self.loss_func(output, target)

                # 反向传播并更新权重
                loss.backward()
                optimizer.step()

                # 记录损失
                batch_loss.append(loss.item())

            # 记录每个 epoch 的平均损失
            epoch_loss.append(sum(batch_loss) / len(batch_loss))

        # 返回本地训练后模型的权重和平均损失
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)

'''class LocalUpdate(object):
    def __init__(self, args, dataset=None, idxs=None):
        self.args = args
        self.loss_func = nn.CrossEntropyLoss()
        self.selected_clients = []
        self.ldr_train = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True)

    def train(self, net):
        net.train()
        # train and update
        optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)

        epoch_loss = []
        for iter in range(self.args.local_ep):
            batch_loss = []
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images, labels = images.to(self.args.device), labels.to(self.args.device)
                net.zero_grad()
                log_probs = net(images)
                loss = self.loss_func(log_probs, labels)
                loss.backward()
                optimizer.step()
                if self.args.verbose and batch_idx % 10 == 0:
                    print('Update Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                        iter, batch_idx * len(images), len(self.ldr_train.dataset),
                               100. * batch_idx / len(self.ldr_train), loss.item()))
                batch_loss.append(loss.item())
            epoch_loss.append(sum(batch_loss)/len(batch_loss))
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)'''

