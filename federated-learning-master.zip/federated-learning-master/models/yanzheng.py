import tenseal as ts  # 引入TenSEAL库
import torch
import numpy as np


# 创建同态加密上下文
def initialize_tenseal():
    # 使用 CKKS 加密方案，支持浮点数加密
    context = ts.context(
        ts.SCHEME_TYPE.CKKS,
        poly_modulus_degree=8192,  # 控制多项式模数的大小
        coeff_mod_bit_sizes=[40, 21, 21, 40]  # 设置系数模数
    )
    # 设置全局缩放因子，用于加密和计算浮点数
    context.global_scale = 2 ** 20

    # 生成 Galois keys 和 relin keys 用于矩阵乘法和其他操作
    context.generate_galois_keys()
    context.generate_relin_keys()

    return context


# 加密模型参数
def encrypt_params(params, context):
    encrypted_params = {}
    shapes = {}

    for k, v in params.items():
        # 展平成一维数组
        shapes[k] = v.shape
        v_flat = v.view(-1).numpy()

        # CKKS 加密
        encrypted_vector = ts.ckks_vector(context, v_flat)
        encrypted_params[k] = encrypted_vector

        # 打印加密后的参数信息（密文，不可直接读取数值）
        print(f"Encrypted parameter: {k}, Encoded as CKKSVector")

    return encrypted_params, shapes


# 解密模型参数
def decrypt_params(encrypted_params, shapes):
    decrypted_params = {}

    for k, encrypted_vector in encrypted_params.items():
        # 解密并恢复形状
        decrypted_vector = encrypted_vector.decrypt()
        decrypted_params[k] = torch.tensor(decrypted_vector).reshape(shapes[k])

    return decrypted_params


# 比较加密解密前后的模型参数
def compare_params(original_params, decrypted_params):
    for key in original_params.keys():
        original_tensor = original_params[key].cpu().numpy()
        decrypted_tensor = decrypted_params[key].cpu().numpy()

        # 计算差异
        diff = np.abs(original_tensor - decrypted_tensor)
        max_diff = np.max(diff)
        mean_diff = np.mean(diff)

        # 打印原始参数、解密后的参数以及误差
        print(f"Decrypted: \n{decrypted_tensor}")
        print(f"Max difference: {max_diff:.6f}, Mean difference: {mean_diff:.6f}")


if __name__ == "__main__":
    # 初始化加密上下文
    context = initialize_tenseal()

    # 生成简单的几个参数
    params = {
        "weight1": torch.tensor([[1.23, 2.34], [3.45, 4.56]]),
        "bias1": torch.tensor([0.12, -0.34]),
        "weight2": torch.tensor([[5.67, -6.78], [7.89, -8.90]]),
    }

    # 打印原始参数
    print("Original parameters:")
    for key, value in params.items():
        print(f"{key}: {value.numpy()}")

    # 加密参数
    encrypted_params, shapes = encrypt_params(params, context)

    # 解密参数
    decrypted_params = decrypt_params(encrypted_params, shapes)

    # 比较原始参数和解密后的参数
    print("\nComparing original and decrypted parameters...")
    compare_params(params, decrypted_params)
