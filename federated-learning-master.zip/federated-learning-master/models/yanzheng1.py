import tenseal as ts  # 引入TenSEAL库
import torch
import numpy as np

# 引入加密和解密函数
def encrypt_model_params_tenseal(model_params, context):
    encrypted_params = {}
    model_shapes = {}

    for k, v in model_params.items():
        # 检查是否为 torch.Tensor，确保数据在加密前移动到 CPU
        if isinstance(v, torch.Tensor):
            # 先保存原始形状
            model_shapes[k] = v.shape  # 保存形状信息

            # 展平成一维数组以便加密
            v_flat = v.cpu().view(-1).numpy()  # 移动到 CPU 并展平成 numpy 数组
        else:
            raise ValueError(f"Expected torch.Tensor but got {type(v)} for {k}")

        # 使用 CKKS 加密
        encrypted_vector = ts.ckks_vector(context, v_flat)
        encrypted_params[k] = encrypted_vector

        # 加密后的检查
        if not isinstance(encrypted_vector, ts.CKKSVector):
            raise ValueError(f"Parameter {k} was not correctly encrypted as CKKSVector.")

    return encrypted_params, model_shapes

def decrypt_model_params_tenseal(encrypted_params, context, model_shapes):
    decrypted_params = {}

    for k, encrypted_vector in encrypted_params.items():
        shape = model_shapes[k]  # 获取加密前的原始形状

        # 解密该向量
        decrypted_vector = encrypted_vector.decrypt()

        # 根据原始形状恢复参数
        if len(shape) > 1:  # 如果是多维参数
            decrypted_params[k] = torch.tensor(decrypted_vector).reshape(shape)  # 恢复多维数组
        else:  # 如果是一维参数，直接转换
            decrypted_params[k] = torch.tensor(decrypted_vector)

    return decrypted_params

# 创建同态加密上下文
def initialize_tenseal():
    # 使用 CKKS 加密方案，支持浮点数加密
    context = ts.context(
        ts.SCHEME_TYPE.CKKS,
        poly_modulus_degree=32768,  # 控制多项式模数的大小，越大安全性越高，但计算开销也增加
        coeff_mod_bit_sizes=[40, 21, 21, 40]  # 设置系数模数
    )
    # 设置全局缩放因子，用于加密和计算浮点数
    context.global_scale = 2 ** 20

    # 生成 Galois keys 和 relin keys 用于矩阵乘法和其他操作
    context.generate_galois_keys()
    context.generate_relin_keys()

    return context

# 比较加密解密前后的模型参数
def compare_weights(original_w, decrypted_w):
    for key in original_w.keys():
        original_tensor = original_w[key].cpu().numpy()
        decrypted_tensor = decrypted_w[key].cpu().numpy()

        # 计算差异
        diff = np.abs(original_tensor - decrypted_tensor)
        max_diff = np.max(diff)
        mean_diff = np.mean(diff)
        print(f"Decrypted: \n{decrypted_tensor}")
        # 输出每层的最大误差和平均误差
        print(f"Layer: {key}, Max difference: {max_diff:.6f}, Mean difference: {mean_diff:.6f}")

# 生成随机模型参数（用于测试）
def generate_random_model():
    model_params = {
        "layer1.weight": torch.randn(100, 100),
        "layer1.bias": torch.randn(100),
    }
    return model_params

if __name__ == "__main__":
    # 初始化加密上下文
    context = initialize_tenseal()

    # 生成随机模型参数
    original_params = generate_random_model()

    # 打印原始模型参数
    print("Original parameters:")
    for key, value in original_params.items():
        print(f"{key}: {value.numpy()}")

    # 加密模型参数
    encrypted_params, model_shapes = encrypt_model_params_tenseal(original_params, context)

    # 解密模型参数
    decrypted_params = decrypt_model_params_tenseal(encrypted_params, context, model_shapes)

    # 对比加密解密后的参数和原始参数
    print("\nComparing original and decrypted parameters...")
    compare_weights(original_params, decrypted_params)
