#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6


import torch
import copy
import tenseal as ts  # 引入TenSEAL库

def FedAvg(w_encrypted):
    w_avg = copy.deepcopy(w_encrypted[0])
    for k in w_avg.keys():
        for i in range(1, len(w_encrypted)):
            # 确保只对加密的 CKKSVector 进行加法运算
            if isinstance(w_encrypted[i][k], ts.CKKSVector):
                w_avg[k] += w_encrypted[i][k]
        # 使用 CKKSVector 的乘法来模拟除法：乘以 1 / len(w_encrypted)
        divisor_reciprocal = 1.0 / len(w_encrypted)
        w_avg[k] = w_avg[k] * divisor_reciprocal  # 使用 CKKSVector 的乘法
    return w_avg














