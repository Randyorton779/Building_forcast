#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @python: 3.6

import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader


'''def test_img(net_g, datatest, args):
    net_g.eval()
    # testing
    test_loss = 0
    correct = 0
    data_loader = DataLoader(datatest, batch_size=args.bs)
    l = len(data_loader)
    for idx, (data, target) in enumerate(data_loader):
        if args.gpu != -1:
            data, target = data.cuda(), target.cuda()
        log_probs = net_g(data)
        # sum up batch loss
        test_loss += F.cross_entropy(log_probs, target, reduction='sum').item()
        # get the index of the max log-probability
        y_pred = log_probs.data.max(1, keepdim=True)[1]
        correct += y_pred.eq(target.data.view_as(y_pred)).long().cpu().sum()

    test_loss /= len(data_loader.dataset)
    accuracy = 100.00 * correct / len(data_loader.dataset)
    if args.verbose:
        print('\nTest set: Average loss: {:.4f} \nAccuracy: {}/{} ({:.2f}%)\n'.format(
            test_loss, correct, len(data_loader.dataset), accuracy))
    return accuracy, test_loss'''
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
import numpy as np


def test_regression(net_g, datatest, args):
    net_g.eval()
    test_loss = 0
    data_loader = DataLoader(datatest, batch_size=args.bs, shuffle=False)

    # 使用均方误差作为损失函数
    loss_func = torch.nn.MSELoss(reduction='sum')  # 设置为 'sum' 以便和之前代码保持一致

    predictions = []
    actuals = []

    with torch.no_grad():  # 不计算梯度，进入测试模式
        for data, target in data_loader:
            # 将数据移动到设备上
            data, target = data.to(args.device), target.to(args.device)

            # 扩展输入维度 (batch_size, sequence_length, input_size)
            data = data.unsqueeze(2)

            # 前向传播，获取模型输出
            output = net_g(data)

            # 收集预测值和实际值
            predictions.append(output.cpu().numpy())
            actuals.append(target.cpu().numpy())

            # 计算损失并累积
            test_loss += loss_func(output, target).item()

    # 计算平均损失
    test_loss /= len(data_loader.dataset)

    if args.verbose:
        print(f'\nTest set: Average loss: {test_loss:.4f}\n')

    # 将所有批次的预测值和实际值拼接起来
    predictions = np.concatenate(predictions, axis=0).squeeze()  # 确保 predictions 是 1D 数组
    actuals = np.concatenate(actuals, axis=0).squeeze()  # 确保 actuals 是 1D 数组

    return test_loss, predictions, actuals


