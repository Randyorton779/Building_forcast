import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from torchvision import datasets, transforms
import pandas as pd
from utils.sampling import mnist_iid, mnist_noniid, cifar_iid
from utils.options import args_parser
from models.Update import LocalUpdate,DatasetSplit
from models.Nets import LSTMModel
from models.Fed import FedAvg
from models.Fed_original import  FedAvg_original
from models.test import test_regression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import TensorDataset
import tenseal as ts  # 引入TenSEAL库
from models.tongtai import encrypt_model_params_tenseal,decrypt_model_params_tenseal,initialize_tenseal
from phe import paillier
import torch
import numpy as np
import copy
from phe import paillier
from sklearn.metrics import mean_squared_error  # 导入MSE计算函数



# 滑窗特征生成函数
def create_rolling_features(data, feature_cols, target_col, input_window, output_window):
    X, y = [], []
    for i in range(len(data) - input_window - output_window + 1):
        X.append(data.iloc[i:i + input_window][feature_cols].values)
        y.append(data.iloc[i + input_window:i + input_window + output_window][target_col].values)
    return np.array(X), np.array(y)


# 主程序
if __name__ == '__main__':
    # 参数解析
    args = args_parser()
    args.device = torch.device('cuda:{}'.format(args.gpu) if torch.cuda.is_available() and args.gpu != -1 else 'cpu')

    # 加载数据
    data = pd.read_csv('Robin_education_Madeline_with_timestamp.csv')
    data['timestamp'] = pd.to_datetime(data['timestamp'], format='%Y/%m/%d %H:%M')
    data.set_index('timestamp', inplace=True)

    # 定义特征列和目标列
    feature_cols = ['month', 'weekday', 'day', 'hour', 'holiday', 'airTemp', 'value']
    target_col = 'value'
    input_window = 168
    output_window = 168

    # 滑窗生成特征和目标
    X, y = create_rolling_features(data, feature_cols, target_col, input_window, output_window)

    # 数据划分
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, shuffle=False)

    # 数据标准化
    scaler_X = MinMaxScaler()
    X_train = scaler_X.fit_transform(X_train.reshape(-1, len(feature_cols))).reshape(X_train.shape)
    X_test = scaler_X.transform(X_test.reshape(-1, len(feature_cols))).reshape(X_test.shape)

    scaler_y = MinMaxScaler()
    y_train = scaler_y.fit_transform(y_train.reshape(-1, 1)).reshape(y_train.shape)
    y_test = scaler_y.transform(y_test.reshape(-1, 1)).reshape(y_test.shape)

    # 转换为 PyTorch 张量
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
    X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, dtype=torch.float32)

    # 创建数据集
    dataset_train = TensorDataset(X_train_tensor, y_train_tensor)
    dataset_test = TensorDataset(X_test_tensor, y_test_tensor)

    # 划分客户端数据
    dict_users = {}
    num_users = args.num_users
    data_size = len(X_train_tensor)
    split_size = data_size // num_users

    for i in range(num_users):
        start_idx = i * split_size
        end_idx = start_idx + split_size if i < num_users - 1 else data_size
        dict_users[i] = DatasetSplit(dataset_train, list(range(start_idx, end_idx)))

    # 模型定义
    input_size = len(feature_cols)
    net_glob = LSTMModel(input_size=input_size, hidden_size=64, num_layers=1, output_size=output_window).to(args.device)
    net_glob.train()
    w_glob = net_glob.state_dict()

    # 联邦学习训练
    for iter in range(args.epochs):
        loss_locals = []
        w_local = []

        idxs_users = np.random.choice(range(args.num_users), max(int(args.frac * args.num_users), 1), replace=False)

        for idx in idxs_users:
            local = LocalUpdate(args=args, dataset=dict_users[idx])
            w, loss = local.train(net=copy.deepcopy(net_glob).to(args.device))
            w_local.append(copy.deepcopy(w))
            loss_locals.append(copy.deepcopy(loss))

        # 聚合权重
        w_glob = FedAvg_original(w_local)
        net_glob.load_state_dict(w_glob)

        print(f'Round {iter + 1}, Average loss: {sum(loss_locals) / len(loss_locals):.4f}')

        # 保存模型
    model_save_path = f'./save1/Robin_Edu_Madeline(local(168-168)).pth'
    # 保存模型
    torch.save(net_glob.state_dict(), model_save_path)
    print(f"Model saved to {model_save_path}")
