import time
from models.paillier_new import PaillierPublicKey, PaillierPrivateKey, generate_paillier_keypair

def test_paillier_encryption():
    # Step 1: 生成密钥对
    print("Step 1: Generating keypair...")
    start_time = time.time()
    public_key, private_key = generate_paillier_keypair(n_length=20)  # 调整密钥长度为 2048 位
    keygen_time = time.time() - start_time
    print(f"Key generation completed in {keygen_time:.4f} seconds.\n")

    # Step 2: 定义需要加密的固定明文值
    plaintext_values = [123, 456, 789, 1024, 2048]  # 固定明文值
    print(f"Plaintext values: {plaintext_values}\n")

    # Step 3: 对明文进行加密
    encrypted_values = []
    print("Step 2: Encrypting plaintext values...")
    start_time = time.time()
    for value in plaintext_values:
        ciphertext = public_key.encrypt(value)
        encrypted_values.append(ciphertext)
    encryption_time = time.time() - start_time
    print(f"Encryption completed in {encryption_time:.4f} seconds.\n")

    # 打印加密后的密文
    print("Encrypted ciphertexts:")
    for i, ciphertext in enumerate(encrypted_values):
        print(f"Plaintext: {plaintext_values[i]} -> Ciphertext: {ciphertext.ciphertext()}")

    # Step 4: 对密文进行解密
    decrypted_values = []
    print("\nStep 3: Decrypting ciphertext values...")
    start_time = time.time()
    for ciphertext in encrypted_values:
        plaintext = private_key.decrypt(ciphertext)
        decrypted_values.append(plaintext)
    decryption_time = time.time() - start_time
    print(f"Decryption completed in {decryption_time:.4f} seconds.\n")

    # 打印解密后的明文
    print("Decrypted plaintexts:")
    for i, plaintext in enumerate(decrypted_values):
        print(f"Ciphertext: {encrypted_values[i].ciphertext()} -> Decrypted Plaintext: {plaintext}")

    # Step 5: 验证解密结果是否与原始明文一致
    print("\nStep 4: Validating results...")
    for original, decrypted in zip(plaintext_values, decrypted_values):
        assert original == decrypted, f"Validation failed: {original} != {decrypted}"
    print("Validation passed! Decrypted values match the original plaintexts.\n")

    # Step 6: 打印总时间
    total_time = keygen_time + encryption_time + decryption_time
    print(f"Total time for key generation, encryption, and decryption: {total_time:.4f} seconds.")

if __name__ == "__main__":
    test_paillier_encryption()
