import matplotlib
import os
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import TensorDataset
import torch
import numpy as np
import copy
from phe import paillier
from models.Fed_original import  FedAvg_original
from utils.options import args_parser
from models.Update import LocalUpdate, DatasetSplit
from models.Nets import LSTMModel
from models.Fed import FedAvg
from models.test import test_regression
from sklearn.metrics import mean_squared_error  # 导入MSE计算函数

# 比较加密前后的参数差异
def compare_weights(original_w, decrypted_w):
    for key in original_w.keys():
        original_tensor = original_w[key].cpu().numpy()
        decrypted_tensor = decrypted_w[key].cpu().numpy()
        diff = np.abs(original_tensor - decrypted_tensor)
        max_diff = np.max(diff)
        mean_diff = np.mean(diff)
        print(f"Layer: {key}, Max difference: {max_diff:.6f}, Mean difference: {mean_diff:.6f}")


# 加密和解密模型参数
def encrypt_model_params_paillier(model_params, public_key):
    encrypted_params = {}
    model_shapes = {}
    for k, v in model_params.items():
        if isinstance(v, torch.Tensor):
            model_shapes[k] = v.shape
            v_flat = v.cpu().view(-1).numpy().tolist()
        else:
            raise ValueError(f"Expected torch.Tensor but got {type(v)} for {k}")
        encrypted_vector = [public_key.encrypt(x) for x in v_flat]
        encrypted_params[k] = encrypted_vector
    return encrypted_params, model_shapes


def decrypt_model_params_paillier(encrypted_params, private_key, model_shapes):
    decrypted_params = {}
    for k, encrypted_vector in encrypted_params.items():
        shape = model_shapes[k]
        decrypted_vector = [private_key.decrypt(x) for x in encrypted_vector]
        decrypted_params[k] = torch.tensor(decrypted_vector).reshape(shape)
    return decrypted_params


def initialize_paillier_keypair(n_length=1024):
    public_key, private_key = paillier.generate_paillier_keypair(n_length=n_length)
    return public_key, private_key

# 滑窗特征生成函数
def create_rolling_features(data, feature_cols, target_col, input_window, output_window):
    X, y = [], []
    for i in range(len(data) - input_window - output_window + 1):
        X.append(data.iloc[i:i + input_window][feature_cols].values)
        y.append(data.iloc[i + input_window:i + input_window + output_window][target_col].values)
    return np.array(X), np.array(y)

# 联邦学习仿真代码
if __name__ == '__main__':
    args = args_parser()
    args.device = torch.device('cuda:{}'.format(args.gpu) if torch.cuda.is_available() and args.gpu != -1 else 'cpu')
    public_key, private_key = initialize_paillier_keypair()

    # 加载多个建筑的数据集
    file_paths = [
        'Robin_education_Madeline_with_timestamp.csv',
        'Robin_education_Margarito_with_timestamp.csv',
        'Robin_education_Megan_with_timestamp.csv',
        'Robin_education_Mercedes_with_timestamp.csv',
        'Robin_education_So_with_timestamp.csv',
    ]
    #数据集
    '''Robin_lodging_Armand_with_timestamp.csv',
    'Robin_lodging_Celia_with_timestamp.csv',
    'Robin_lodging_Donna_with_timestamp.csv',
    'Robin_lodging_Dorthy_with_timestamp.csv',
    'Robin_lodging_Elmer_with_timestamp.csv',
    'Robin_office_Sammie_with_timestamp.csv',
    'Robin_office_Serena_with_timestamp.csv',
    'Robin_office_Shirlene_with_timestamp.csv',
    'Robin_office_Victor_with_timestamp.csv',
    'Robin_office_Zelma_with_timestamp.csv'''

    dict_users = {}
    #num_users = len(file_paths)
    # 定义特征列和目标列
    feature_cols = ['month', 'weekday', 'day', 'hour', 'holiday', 'airTemp', 'value']
    target_col = 'value'
    input_window = 168
    output_window = 168

    for i, file_path in enumerate(file_paths):
        data = pd.read_csv(file_path)
        data['timestamp'] = pd.to_datetime(data['timestamp'], format='%Y/%m/%d %H:%M')
        data.set_index('timestamp', inplace=True)

        feature_cols = ['month', 'weekday', 'day', 'hour', 'holiday', 'airTemp', 'value']
        target_col = 'value'
        # 滑窗生成特征和目标
        X, y = create_rolling_features(data, feature_cols, target_col, input_window, output_window)
        # 数据划分
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, shuffle=False)

        # 数据标准化
        scaler_X = MinMaxScaler()
        X_train = scaler_X.fit_transform(X_train.reshape(-1, len(feature_cols))).reshape(X_train.shape)
        X_test = scaler_X.transform(X_test.reshape(-1, len(feature_cols))).reshape(X_test.shape)

        scaler_y = MinMaxScaler()
        y_train = scaler_y.fit_transform(y_train.reshape(-1, 1)).reshape(y_train.shape)
        y_test = scaler_y.transform(y_test.reshape(-1, 1)).reshape(y_test.shape)

        # 转换为 PyTorch 张量
        X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
        X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
        y_test_tensor = torch.tensor(y_test, dtype=torch.float32)

        # 创建数据集
        dataset_train = TensorDataset(X_train_tensor, y_train_tensor)
        dataset_test = TensorDataset(X_test_tensor, y_test_tensor)

        dict_users[i] = DatasetSplit(dataset_train, list(range(len(X_train_tensor))))

    if args.model == 'lstm' and args.dataset == 'energy':
        net_glob = LSTMModel(input_size=len(feature_cols), hidden_size=64, num_layers=1, output_size=output_window).to(args.device)
    else:
        exit('Error: unrecognized model')
    net_glob.train()
    w_glob = net_glob.state_dict()

    if args.all_clients:
        w_local = [w_glob for i in range(args.num_users)] # 每个客户端的初始权重设置为全局模型权重

    for iter in range(args.epochs):
        loss_locals = []
        if not args.all_clients:
            w_local = []
        m = max(int(args.frac * args.num_users), 1)
        idxs_users = np.random.choice(range(args.num_users), m, replace=False)

        for idx in range(args.num_users):
            if idx in idxs_users:
                local = LocalUpdate(args=args, dataset=dict_users[idx])
                w, loss = local.train(net=copy.deepcopy(net_glob).to(args.device))
                if args.all_clients:
                    w_local[idx] = copy.deepcopy(w)
                else:
                    w_local.append(copy.deepcopy(w))
                loss_locals.append(copy.deepcopy(loss))

        w_glob = FedAvg_original(w_local)
        net_glob.load_state_dict(w_glob)
        loss_avg = sum(loss_locals) / len(loss_locals)
        print(f'Round {iter + 1}, Average loss: {loss_avg:.4f}')


    #保存模型
    model_save_path = f'./save1/Robin_Edu_global(168-168).pth'
    # 保存模型
    torch.save(net_glob.state_dict(), model_save_path)
    print(f"Model saved to {model_save_path}")



