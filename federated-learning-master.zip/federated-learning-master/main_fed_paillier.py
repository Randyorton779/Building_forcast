import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from torchvision import datasets, transforms
import pandas as pd
from utils.sampling import mnist_iid, mnist_noniid, cifar_iid
from utils.options import args_parser
from models.Update import LocalUpdate,DatasetSplit
from models.Nets import LSTMModel
from models.Fed import FedAvg
from models.Fed_original import  FedAvg_original
from models.test import test_regression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import TensorDataset
import tenseal as ts  # 引入TenSEAL库
from models.tongtai import encrypt_model_params_tenseal,decrypt_model_params_tenseal,initialize_tenseal
from phe import paillier
import torch
import numpy as np
import copy
from phe import paillier

# 比较加密前后的参数差异
def compare_weights(original_w, decrypted_w):
    for key in original_w.keys():
        original_tensor = original_w[key].cpu().numpy()
        decrypted_tensor = decrypted_w[key].cpu().numpy()

        # 计算差异
        diff = np.abs(original_tensor - decrypted_tensor)
        max_diff = np.max(diff)
        mean_diff = np.mean(diff)

        # 输出每层的最大误差和平均误差
        print(f"Layer: {key}, Max difference: {max_diff:.6f}, Mean difference: {mean_diff:.6f}")


# 客户端加密模型权重（使用Paillier加密）
def encrypt_model_params_paillier(model_params, public_key):
    encrypted_params = {}
    model_shapes = {}

    for k, v in model_params.items():
        # 检查是否为 torch.Tensor，确保数据在加密前移动到 CPU
        if isinstance(v, torch.Tensor):
            # 先保存原始形状
            model_shapes[k] = v.shape  # 保存形状信息

            # 展平成一维数组以便加密
            v_flat = v.cpu().view(-1).numpy().tolist()  # 移动到 CPU 并展平成 numpy 列表
        else:
            raise ValueError(f"Expected torch.Tensor but got {type(v)} for {k}")

        # 使用 Paillier 加密
        encrypted_vector = [public_key.encrypt(x) for x in v_flat]
        encrypted_params[k] = encrypted_vector  # 现在返回字典格式

    return encrypted_params, model_shapes

# 客户端解密模型权重
def decrypt_model_params_paillier(encrypted_params, private_key, model_shapes):
    decrypted_params = {}

    # 使用 .items() 迭代字典中的键值对
    for k, encrypted_vector in encrypted_params.items():
        shape = model_shapes[k]  # 获取加密前的原始形状

        # 解密该向量
        decrypted_vector = [private_key.decrypt(x) for x in encrypted_vector]

        # 根据原始形状恢复参数
        decrypted_params[k] = torch.tensor(decrypted_vector).reshape(shape)

    return decrypted_params


# 创建Paillier密钥对
def initialize_paillier_keypair(n_length=1024):
    public_key, private_key = paillier.generate_paillier_keypair(n_length=n_length)
    return public_key, private_key


# 服务器端：累加各客户端的加密参数
def FedAvg_paillier_server(w_encrypted):
    # 深拷贝第一个加密的权重作为累加值的初始值
    w_sum = copy.deepcopy(w_encrypted[0])
    # 对每个参数逐层进行加法
    for k in w_sum.keys():
        for i in range(1, len(w_encrypted)):
            # 确保只对加密的 Paillier 加密元素进行加法
            if isinstance(w_encrypted[i][k], paillier.EncryptedNumber):
                w_sum[k] += w_encrypted[i][k]

    # 返回累加后的加密参数给客户端
    return w_sum


def FedAvg_paillier_client(w_sum, private_key, num_clients, model_shapes):
    # 调用解密函数解密服务器端累加的加密参数
    decrypted_params = decrypt_model_params_paillier(w_sum, private_key, model_shapes)

    # 计算平均值：对每个解密后的参数进行除法
    for k in decrypted_params.keys():
        decrypted_params[k] = decrypted_params[k] / num_clients

    # 返回解密后的平均模型参数
    return decrypted_params



if __name__ == '__main__':
    # parse args参数传递
    args = args_parser()
    args.device = torch.device('cuda:{}'.format(args.gpu) if torch.cuda.is_available() and args.gpu != -1 else 'cpu')

    # 初始化 TenSEAL 上下文(同态加密)
    public_key, private_key = initialize_paillier_keypair()

    # 一、load dataset and split users
    # Load dataset and split users for energy forecasting task
    if args.dataset == 'energy':
        # 1. 加载能耗数据
        data = pd.read_csv('time_energy_consumption.csv')
        data['timestamp'] = pd.to_datetime(data['timestamp'], format='%Y/%m/%d %H:%M')
        data.set_index('timestamp', inplace=True)
        # 2. 生成滞后特征（例如前48小时的滞后特征）
        for i in range(1, 49):
            data[f'lag_{i}'] = data['energy_consumption'].shift(i)
        # 3. 删除缺失值
        data = data.dropna()
        # 4. 划分特征和标签
        X = data[[f'lag_{i}' for i in range(1, 49)]].values  # 滞后特征
        y = data['energy_consumption'].values  # 能耗值
        # 5. 划分数据集为训练集和测试集
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)
        # 6. 特征和目标的标准化
              # 标准化特征
        scaler_X = MinMaxScaler()
        X_train = scaler_X.fit_transform(X_train)
        X_test = scaler_X.transform(X_test)
              # 标准化目标变量
        scaler_y = MinMaxScaler()
        y_train = scaler_y.fit_transform(y_train.reshape(-1, 1))
        y_test = scaler_y.transform(y_test.reshape(-1, 1))
        # 7. 将数据转换为 PyTorch 张量
        X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
        # 8. 全局dataset
        dataset_train = TensorDataset(X_train_tensor, y_train_tensor)
        X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
        y_test_tensor = torch.tensor(y_test, dtype=torch.float32)
        dataset_test = TensorDataset(X_test_tensor, y_test_tensor)
        # 9. 将训练集划分给不同用户（模拟联邦学习的客户端）
        dict_users = {}
        num_users = args.num_users
        data_size = len(X_train_tensor)
        split_size = data_size // num_users
           #处理数据量不能被 num_users 整除的情况
        remainder = data_size % num_users
        # 根据每个客户端的索引范围，使用 DatasetSplit 划分数据
        for i in range(num_users):
            start_idx = i * split_size
            end_idx = start_idx + split_size
            # 分配剩余的数据到最后一个客户端
            if i == num_users - 1:
                end_idx = data_size  # 最后一个客户端拿到所有剩余的数据
            # 打印检查客户端数据划分的索引范围
            print(f"Client {i} gets data from index {start_idx} to {end_idx - 1}")
            # 传入全局 dataset_train 和每个客户端对应的索引范围
            dict_users[i] = DatasetSplit(dataset_train, list(range(start_idx, end_idx)))
        # 验证是否所有客户端的数据划分正确
        for i in range(num_users):
            print(f"Client {i} has {len(dict_users[i])} samples.")


    # 二、build model
    # 1. 修改模型选择逻辑
    if args.model == 'lstm' and args.dataset == 'energy':
        # 定义 LSTM 模型，输入维度是滞后特征的数量（例如 48），输出维度是 1
        net_glob = LSTMModel(input_size=1, hidden_size=64, num_layers=1, output_size=1).to(args.device)
    else:
        exit('Error: unrecognized model')
    print(net_glob)#打印模型
    net_glob.train()#训练模式

    # 三、copy weights
    w_glob = net_glob.state_dict()  # 保存了当前全局模型 net_glob 的权重

    # 四、train
    # 如果使用所有客户端聚合
    if args.all_clients:
        print("Aggregation over all clients")
        w_local = [w_glob for i in range(args.num_users)]  # 每个客户端的初始权重设置为全局模型权重

    # 开始训练过程
    for iter in range(args.epochs):
        loss_locals = []
        if not args.all_clients:
            w_locals_en = []  # 如果不使用所有客户端，每轮清空本地权重列表
            w_local = []
        # 随机选择部分客户端进行训练
        m = max(int(args.frac * args.num_users), 1)  # 选取的客户端数量
        idxs_users = np.random.choice(range(args.num_users), m, replace=False)

        # 遍历所有客户端，确保每个客户端都有参与
        for idx in range(args.num_users):
            if idx in idxs_users:
                # 选中的客户端进行本地训练
                local = LocalUpdate(args=args, dataset=dict_users[idx])
                w, loss = local.train(net=copy.deepcopy(net_glob).to(args.device))

                # 选中的客户端进行加密
                encrypted_w, model_shapes = encrypt_model_params_paillier(w, public_key)
                # 保存加密后的权重
                if args.all_clients:
                    w_locals_en[idx] = copy.deepcopy(encrypted_w)
                    w_local[idx] = copy.deepcopy(w)
                else:
                    w_locals_en.append(copy.deepcopy(encrypted_w))
                    w_local.append(copy.deepcopy(w))
                loss_locals.append(copy.deepcopy(loss))

        # 在服务器端进行聚合
        w_glob_encrypted = FedAvg_paillier_server(w_locals_en)
        w_glob = FedAvg_original(w_local)
        #print(w_glob)
        #print("Wait")
        # 解密后更新全局模型
        w_glob_decrypted = FedAvg_paillier_client(w_glob_encrypted, private_key, num_clients=len(idxs_users), model_shapes=model_shapes)
        #print(w_glob_decrypted)
        # 调用函数比较权重
        compare_weights(w_glob, w_glob_decrypted)
        # 将聚合后的全局权重加载到全局模型
        net_glob.load_state_dict(w_glob_decrypted)

        # 计算并打印本轮的平均损失
        loss_avg = sum(loss_locals) / len(loss_locals)
        print(f'Round {iter + 1}, Average loss: {loss_avg:.4f}')


    # 绘制损失曲线
    plt.figure()
    plt.plot(range(len(loss_locals)), loss_locals)
    plt.ylabel('Train Loss')
    plt.xlabel('Rounds')
    plt.savefig(f'./save/fed_{args.dataset}_{args.model}_{args.epochs}_C{args.frac}_iid{args.iid}.png')

    # 五、test
    # 测试过程
    net_glob.eval()
    loss_test, predictions, actuals = test_regression(net_glob, dataset_test, args)
    # 反标准化预测值和实际值
    predictions = predictions.reshape(-1, 1)
    predictions_original_scale = scaler_y.inverse_transform(predictions)
    actuals = actuals.reshape(-1,1)
    actuals_original_scale = scaler_y.inverse_transform(actuals)

    # 绘制实际值与预测值的比较图
    plt.figure(figsize=(10, 5))
    plt.plot(actuals_original_scale, label='Actual', color='blue')
    plt.plot(predictions_original_scale, label='Predicted', color='orange')
    plt.xlabel('Sample Index')
    plt.ylabel('Energy Consumption')
    plt.title('Actual vs Predicted Energy Consumption')
    plt.legend()
    # 保存图像到本地文件
    plt.savefig('plot.png')




