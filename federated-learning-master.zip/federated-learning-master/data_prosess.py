import pandas as pd

# 加载文件
file_path = 'data/New_data/Robin_office_Zelma.csv'  # 替换为你的实际文件路径
data = pd.read_csv(file_path, engine='python')

# 生成时间戳列（从2016年1月到2017年12月，每小时一个数据）
timestamps = pd.date_range(start='2016-01-01 00:00:00', end='2017-12-31 23:00:00', freq='H')

# 将时间戳添加到数据中
data['timestamp'] = timestamps

# 保存更新后的文件
updated_file_path = 'Robin_office_Zelma_with_timestamp.csv'
data.to_csv(updated_file_path, index=False)

print(f"文件已保存到: {updated_file_path}")
