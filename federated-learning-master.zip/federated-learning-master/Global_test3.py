import torch
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
from models.Nets import LSTMModel
from sklearn.model_selection import train_test_split

# 滑窗特征生成函数
def create_rolling_features(data, feature_cols, target_col, input_window, output_window):
    X, y = [], []
    for i in range(0, len(data) - input_window - output_window + 1, output_window):  # 步长等于 output_window
        X.append(data.iloc[i:i + input_window][feature_cols].values)
        y.append(data.iloc[i + input_window:i + input_window + output_window][target_col].values)
    return np.array(X), np.array(y)

# 测试脚本主程序
if __name__ == '__main__':
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 加载清理后的数据
    data = pd.read_csv('cleaned_build1000_data.csv')
    data['timestamp'] = pd.to_datetime(data['timestamp'], format='%Y/%m/%d %H:%M')
    data.set_index('timestamp', inplace=True)

    # 定义特征列和目标列
    feature_cols = ['meter_reading', 'air_temperature', 'dew_temperature', 'month', 'day', 'hour', 'weekday', 'is_weekday']
    target_col = 'meter_reading'
    input_window = 48
    output_window = 24

    # 滑窗生成特征和目标（步长为 output_window，避免重复预测）
    X, y = create_rolling_features(data, feature_cols, target_col, input_window, output_window)

    # 数据划分
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, shuffle=False)

    # 数据标准化
    scaler_X = MinMaxScaler()
    X_train = scaler_X.fit_transform(X_train.reshape(-1, len(feature_cols))).reshape(X_train.shape)
    X_test = scaler_X.transform(X_test.reshape(-1, len(feature_cols))).reshape(X_test.shape)

    scaler_y = MinMaxScaler()
    y_train = scaler_y.fit_transform(y_train.reshape(-1, 1)).reshape(y_train.shape)
    y_test = scaler_y.transform(y_test.reshape(-1, 1)).reshape(y_test.shape)

    # 转换为 PyTorch 张量
    X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, dtype=torch.float32)

    # 加载模型
    input_size = len(feature_cols)
    output_size = output_window
    model_path = './save/fed_1000_24.pth'

    net_glob = LSTMModel(input_size=input_size, hidden_size=64, num_layers=1, output_size=output_size).to(device)
    net_glob.load_state_dict(torch.load(model_path))
    net_glob.eval()
    # len(X_test_tensor)
    # 预测测试集
    predictions, actuals = [], []
    with torch.no_grad():
        for i in range(25):
            # 提取测试样本
            X_sample = X_test_tensor[i].unsqueeze(0).to(device)  # 添加 batch 维度
            y_actual = y_test_tensor[i].cpu().numpy()

            # 进行预测
            y_pred = net_glob(X_sample).cpu().numpy()

            # 保存预测值和实际值
            predictions.append(y_pred)
            actuals.append(y_actual)

    # 转换为原始比例
    predictions = np.vstack(predictions).reshape(-1, output_window)
    actuals = np.vstack(actuals).reshape(-1, output_window)
    predictions_original = scaler_y.inverse_transform(predictions)
    actuals_original = scaler_y.inverse_transform(actuals)
    predictions_original = predictions_original.reshape(-1)
    actuals_original = actuals_original.reshape(-1)

    # 计算 MSE
    mse = mean_squared_error(actuals_original, predictions_original)
    print(f"Mean Squared Error (MSE): {mse:.4f}")


    # 绘制结果
    plt.figure(figsize=(18, 9))
    plt.plot(actuals_original, label='Actual (First Hour)', color='blue')
    plt.plot(predictions_original, label='Predicted (First Hour)', color='orange')
    plt.title("Actual vs Predicted Meter Reading (First Hour of Prediction)")
    plt.xlabel("Sample Index")
    plt.ylabel("Meter Reading")
    plt.legend()
    plt.savefig('rolling_forecast_no_overlap.png')
    print("Prediction plot saved as 'rolling_forecast_no_overlap.png'")
