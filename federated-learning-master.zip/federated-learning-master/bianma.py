import numpy as np

# 定义信道矩阵 H (2x2 MIMO 系统)
H = np.array([[1, 0.5], [0.3, 1]])

# 定义发送符号向量 s
s = np.array([1+1j, 2-1j])

# ZF 预编码矩阵 W_ZF = (H^H * H)^(-1) * H^H
H_hermitian = np.conjugate(H.T)  # H 的共轭转置
W_ZF = np.linalg.inv(H_hermitian @ H) @ H_hermitian

# 预编码后的发送信号
x = W_ZF @ s

print("预编码后的发送信号: ", x)

# 模拟接收信号 y = H * x
y = H @ x

print("接收端接收到的信号: ", y)
