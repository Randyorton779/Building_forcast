import argparse


def args_parser():
    parser = argparse.ArgumentParser()

    # Federated arguments
    parser.add_argument('--epochs', type=int, default=10, help="number of communication rounds (epochs)")
    parser.add_argument('--num_users', type=int, default=5, help="number of clients/users")
    parser.add_argument('--frac', type=float, default=1, help="fraction of clients to use per round")
    parser.add_argument('--local_ep', type=int, default=20, help="number of local epochs per client")
    parser.add_argument('--local_bs', type=int, default=64, help="local batch size for client training")
    parser.add_argument('--bs', type=int, default=64, help="batch size for testing")
    parser.add_argument('--lr', type=float, default=0.0001, help="learning rate")
    parser.add_argument('--momentum', type=float, default=0.5, help="SGD momentum")
    parser.add_argument('--split', type=str, default='user', help="train-test split type, user or sample")

    # Model arguments
    parser.add_argument('--model', type=str, default='lstm', help='model type (default: lstm)')

    # Dataset arguments
    parser.add_argument('--dataset', type=str, default='energy', help="dataset name (default: energy)")

    # System arguments
    # parser.add_argument('--device', type=str, default='cpu', help="GPU ID, -1 for CPU")
    parser.add_argument('--gpu', type=int, default=-1, help="GPU ID, -1 for CPU")
    parser.add_argument('--seed', type=int, default=1, help='random seed for reproducibility')

    # Additional options
    parser.add_argument('--iid', action='store_true', help='whether the data is IID across clients')
    parser.add_argument('--stopping_rounds', type=int, default=10, help='rounds of early stopping')
    parser.add_argument('--verbose', action='store_true', default=True, help='verbose printing')
    parser.add_argument('--all_clients', action='store_true', default=False, help='aggregation over all clients')

    args = parser.parse_args()
    return args
